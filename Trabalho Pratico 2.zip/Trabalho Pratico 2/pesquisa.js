
fetch ('https://diwserver.vps.webdock.cloud/products?')
    .then(res => res.json ())
    .then(data => {
        let pesquisa = [
           for (let i = 0; i < data.results.length; i++) {
                let products = data.results[i];
                ${products.title};
            }
        ]
    })
    //let pesquisas = [
        //"tenis", "bola", "camisa", "calsa", "meia"
    //]