const searchwrapper = document.querySelector(`.texto-pesquisa`);
const inputBox = searchwrapper.querySelector(`.input`);
const pesquisaBox = searchwrapper.querySelector(`.list`);
const botton = searchwrapper.querySelector(`.botao`);
let linkTag = searchwrapper.querySelector(`a`);
let webLink;
inputBox.onkeyup=(e)=>{
    let userData = e.target.value;
    let emptyArrary = [];
    if(e.key==`Enter`){
        if(userData){
            fetch (`https://diwserver.vps.webdock.cloud/products?`)
                window.open(`https://diwserver.vps.webdock.cloud/products/search?query=${userData}`, `_blank`);
        }
    }

    if(userData){
        botton.onclick = ()=>{
            weblink = `https://diwserver.vps.webdock.cloud/products/search?query=${userData}`;
            linkTag.setAttribute(`href`, webLink);
            linkTag.click();
        }
        emptyArrary = pesquisas.filter((data)=>{
            return data.toLocaleLowerCase().startsWith(userData.toLocaleLowerCase());
        });
        emptyArrary = emptyArrary.map((data)=>{
            return data = `<li>${data}</li>`;
        });
        searchwrapper.classList.add(`active`);
        showpesquisa(emptyArrary);
        let allLIst = pesquisaBox.querySelectorAll(`li`);
        for (let i = 0; i < allLIst.length; i++) {
            allLIst[i].setAttribute(`onclick`, `select(this)`);
        }
    }
}

function select(element){
    let selectData = element.textContent;
    inputBox.value = selectData;
    botton.onclick = ()=>{
        weblink = `https://diwserver.vps.webdock.cloud/products/search?query=${selectData}`;
        linkTag.setAttribute(`href`, webLink);
        linkTag.click();
    }
    searchwrapper.classList.remove(`active`);
}

function showpesquisa(list){
    let listData;
    if(!list.lenght){
        userValue = pesquisaBox.value;
        listData = `<li>${userData}</li>`;
    }
    else{
        listData = list.join(``);
    }

    pesquisaBox.innerHTML = listData;
}